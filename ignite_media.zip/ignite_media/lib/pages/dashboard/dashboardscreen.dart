import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_profile_picture/flutter_profile_picture.dart';
import 'package:ignite_media/di/contacts_di.dart';
import 'package:ignite_media/di/login_di.dart';
import 'package:ignite_media/pages/dashboard/blocs/contacts_bloc/contacts_bloc.dart';
import 'package:ignite_media/utils/appcolors.dart';
import 'package:ignite_media/utils/strings.dart';
import 'package:ignite_media/utils/textstyle_extenstion.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';

import 'widgets/user_card_widget.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primaryColor,
      body: Column(
        children: [
          const SizedBox(
            height: 35,
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                    onPressed: () {
                      LoginDi.logoutUser(context);
                    },
                    icon: const Icon(Icons.menu)),
                Text(
                  Strings.contactTitle,
                  style: const TextStyle().bold,
                ),
                ProfilePicture(
                    name: FirebaseAuth.instance.currentUser!.email!,
                    radius: 20,
                    fontsize: 17)
              ],
            ),
          ),
          Expanded(
              child: SizedBox(
            child: BlocProvider(
              create: (context) => ContactsBloc()..add(LoadContacts()),
              child: BlocBuilder<ContactsBloc, ContactsState>(
                builder: (context, state) {
                  if (state is ContactsList) {
                    return RefreshIndicator(
                      color: AppColors.focusedColor,
                      onRefresh: () {
                        return ContactsDi.saveContacts().then((value) {
                          BlocProvider.of<ContactsBloc>(context)
                              .add(LoadContacts());
                        });
                      },
                      child: ListView.builder(
                        itemCount: state.contacts.length,
                        itemBuilder: (context, index) {
                          return UserCard(user: state.contacts[index]);
                        },
                      ),
                    );
                  } else {
                    return Center(
                      child: LoadingAnimationWidget.hexagonDots(
                          color: AppColors.focusedColor, size: 60),
                    );
                  }
                },
              ),
            ),
          ))
        ],
      ),
    );
  }
}
