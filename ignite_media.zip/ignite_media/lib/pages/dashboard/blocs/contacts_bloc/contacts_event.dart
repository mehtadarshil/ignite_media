part of 'contacts_bloc.dart';

@immutable
abstract class ContactsEvent {}

class LoadContacts extends ContactsEvent {}
