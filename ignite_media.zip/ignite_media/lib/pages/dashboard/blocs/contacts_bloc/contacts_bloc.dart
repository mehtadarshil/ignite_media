// ignore_for_file: depend_on_referenced_packages

import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:ignite_media/di/contacts_di.dart';
import 'package:ignite_media/utils/db_keys.dart';
import 'package:ignite_media/utils/models/user_model.dart';
import 'package:meta/meta.dart';

part 'contacts_event.dart';
part 'contacts_state.dart';

class ContactsBloc extends Bloc<ContactsEvent, ContactsState> {
  ContactsBloc() : super(ContactsInitial()) {
    on<LoadContacts>((event, emit) async {
      if (GetStorage().read(DBkeys.initial) == null ||
          GetStorage().read(DBkeys.initial) == false) {
        await ContactsDi.saveContacts();
        emit(ContactsList(await ContactsDi.readContacts()));
      } else {
        emit(ContactsList(await ContactsDi.readContacts()));
      }
    });
  }
}
