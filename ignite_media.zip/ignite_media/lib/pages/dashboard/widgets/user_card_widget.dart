import 'package:flutter/material.dart';
import 'package:flutter_profile_picture/flutter_profile_picture.dart';
import 'package:get_storage/get_storage.dart';
import 'package:ignite_media/di/chat_handler_di.dart';
import 'package:ignite_media/pages/chatroom/chatroom_screen.dart';
import 'package:ignite_media/utils/appcolors.dart';
import 'package:ignite_media/utils/db_keys.dart';
import 'package:ignite_media/utils/models/user_model.dart';

class UserCard extends StatelessWidget {
  const UserCard({
    Key? key,
    required this.user,
  }) : super(key: key);

  final UserModel user;

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 7),
      height: 70,
      decoration: BoxDecoration(
          color: AppColors.whiteColor, borderRadius: BorderRadius.circular(20)),
      child: ListTile(
        onTap: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ChatRoomScreen(
                  chatroom: ChatHandler.chatroomidMaker(
                      user.number, GetStorage().read(DBkeys.currentNumber)),
                  userModel: user,
                ),
              ));
        },
        leading: user.profile.isEmpty
            ? ProfilePicture(name: user.name, radius: 20, fontsize: 17)
            : const CircleAvatar(
                backgroundColor: AppColors.focusedColor,
                radius: 20,
              ),
        title: Text(user.name),
        subtitle: Text(user.number),
        trailing: const Icon(Icons.message),
      ),
    );
  }
}
