part of 'reply_controller_bloc.dart';

@immutable
abstract class ReplyControllerState {}

class ReplyControllerInitial extends ReplyControllerState {}

class ReplyedTextState extends ReplyControllerState {
  final String replyText;

  ReplyedTextState(this.replyText);
}
