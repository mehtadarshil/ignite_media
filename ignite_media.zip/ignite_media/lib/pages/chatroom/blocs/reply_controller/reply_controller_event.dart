part of 'reply_controller_bloc.dart';

@immutable
abstract class ReplyControllerEvent {}

class OnReplyAdd extends ReplyControllerEvent {
  final String replyText;

  OnReplyAdd(this.replyText);
}

class OnReplyRemove extends ReplyControllerEvent {}
