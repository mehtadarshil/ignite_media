part of 'register_bloc.dart';

@immutable
abstract class RegisterEvent {}

class RegisterUser extends RegisterEvent {
  final String email;
  final String username;
  final String number;
  final String password;
  final BuildContext context;

  RegisterUser(
      {required this.email,
      required this.username,
      required this.number,
      required this.password,
      required this.context});
}
