import 'package:flutter/material.dart';
import 'package:ignite_media/utils/strings.dart';
import 'package:ignite_media/utils/textstyle_extenstion.dart';

class AlreadyHaveAcc extends StatelessWidget {
  const AlreadyHaveAcc({
    Key? key,
    required this.onTap,
  }) : super(key: key);
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text(Strings.alreadyHaveAcc),
        GestureDetector(
          onTap: onTap,
          child: Text(
            Strings.clickHere,
            style: const TextStyle().clickableText,
          ),
        )
      ],
    );
  }
}
