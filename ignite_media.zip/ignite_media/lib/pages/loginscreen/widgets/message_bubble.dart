import 'package:chat_bubbles/chat_bubbles.dart';
import 'package:flutter/material.dart';
import 'package:ignite_media/utils/appcolors.dart';
import 'package:ignite_media/utils/models/message_data_model.dart';

class CustomMessageBubble extends StatelessWidget {
  const CustomMessageBubble(
      {super.key, required this.messageData, required this.onDrag});

  final MessageData messageData;
  final VoidCallback onDrag;

  @override
  Widget build(BuildContext context) {
    if (messageData.messageType == MessageType.text) {
      return GestureDetector(
        onHorizontalDragEnd: (details) {
          onDrag;
        },
        child: BubbleSpecialThree(
          text: messageData.text,
          color:
              messageData.isme ? AppColors.focusedColor : AppColors.whiteColor,
          isSender: messageData.isme,
          tail: true,
        ),
      );
    } else {
      return GestureDetector(
        onHorizontalDragEnd: (details) {
          onDrag;
        },
        child: Column(
          children: [
            BubbleSpecialThree(
              text: messageData.text,
              color: messageData.isme
                  ? AppColors.focusedColor
                  : AppColors.whiteColor,
              isSender: messageData.isme,
              tail: true,
            ),
          ],
        ),
      );
    }
  }
}
