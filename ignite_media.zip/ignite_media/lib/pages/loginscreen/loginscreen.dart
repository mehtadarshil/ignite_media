import 'dart:io';

import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ignite_media/di/login_di.dart';
import 'package:ignite_media/pages/loginscreen/blocs/show_password/show_password_cubit.dart';
import 'package:ignite_media/pages/loginscreen/widgets/donthaveacc.dart';
import 'package:ignite_media/pages/registerscreen/registerscreen.dart';
import 'package:ignite_media/utils/appcolors.dart';
import 'package:ignite_media/utils/strings.dart';
import 'package:ignite_media/utils/widgets/common_appbar.dart';
import 'package:ignite_media/utils/widgets/common_textfield.dart';
import 'package:ignite_media/utils/widgets/loginbutton.dart';
import 'package:rive/rive.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  FocusNode emailfocusNode = FocusNode();
  final TextEditingController emailController = TextEditingController();

  FocusNode passwordfocusNode = FocusNode();
  final TextEditingController passwordController = TextEditingController();
  StateMachineController? machineController;

  SMIInput<bool>? isChecking;
  SMIInput<double>? numLook;
  SMIInput<bool>? isHandsUp;
  SMIInput<bool>? trigSuccess;
  SMIInput<bool>? trigFail;

  @override
  void initState() {
    emailfocusNode.addListener(emailFocus);
    passwordfocusNode.addListener(passwordFocus);
    super.initState();
  }

  @override
  void dispose() {
    emailfocusNode.removeListener(emailFocus);
    passwordfocusNode.removeListener(passwordFocus);
    super.dispose();
  }

  void emailFocus() {
    isChecking?.change(emailfocusNode.hasFocus);
  }

  void passwordFocus() {
    isHandsUp?.change(passwordfocusNode.hasFocus);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primaryColor,
      body: FadeInUp(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            children: [
              const SizedBox(
                height: 35,
              ),
              CommonAppbar(
                onBack: () {
                  if (Navigator.canPop(context)) {
                    Navigator.pop(context);
                  }
                },
                onExit: () {
                  exit(0);
                },
                title: Strings.loginTitle,
              ),
              SizedBox(
                  height: 250,
                  width: double.infinity,
                  child: RiveAnimation.asset(
                    Strings.pandaRivePath,
                    fit: BoxFit.cover,
                    stateMachines: const [Strings.machineName],
                    onInit: (p0) {
                      machineController = StateMachineController.fromArtboard(
                          p0, Strings.machineName);

                      if (machineController == null) return;

                      p0.addController(machineController!);
                      isChecking = machineController?.findInput('isChecking');
                      numLook = machineController?.findInput('numLook');
                      isHandsUp = machineController?.findInput('isHandsUp');
                      trigSuccess = machineController?.findInput('trigSuccess');
                      trigFail = machineController?.findInput('trigFail');
                    },
                  )),
              Container(
                padding: const EdgeInsets.all(10),
                margin: const EdgeInsets.symmetric(horizontal: 20),
                decoration: BoxDecoration(
                    color: AppColors.whiteColor,
                    borderRadius: BorderRadius.circular(25)),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CommonTextField(
                      controller: emailController,
                      hintText: Strings.emailHintText,
                      focusNode: emailfocusNode,
                      onChanged: (value) {
                        numLook?.change(value.length.toDouble());
                      },
                      isPassword: false,
                      showPassword: true,
                      onTap: () {},
                      keyboardType: TextInputType.emailAddress,
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    BlocProvider(
                      create: (context2) => ShowPasswordCubit(),
                      child: BlocBuilder<ShowPasswordCubit, ShowPassword>(
                        builder: (context2, state) {
                          return CommonTextField(
                            controller: passwordController,
                            hintText: Strings.passwordHintText,
                            focusNode: passwordfocusNode,
                            onChanged: (value) {},
                            isPassword: true,
                            keyboardType: TextInputType.visiblePassword,
                            showPassword: state.showPassword,
                            onTap: () {
                              if (state.showPassword) {
                                BlocProvider.of<ShowPasswordCubit>(context2)
                                    .hidePassword();
                              } else {
                                BlocProvider.of<ShowPasswordCubit>(context2)
                                    .showPassword();
                              }
                            },
                          );
                        },
                      ),
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    LoginButton(
                      text: Strings.loginTitle,
                      onPressed: () {
                        LoginDi.loginUser(emailController.text,
                            passwordController.text, context);
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 25,
              ),
              DontHaveAcc(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => RegisterScreen(),
                      ));
                },
              ),
              const SizedBox(
                height: 50,
              )
            ],
          ),
        ),
      ),
    );
  }
}
