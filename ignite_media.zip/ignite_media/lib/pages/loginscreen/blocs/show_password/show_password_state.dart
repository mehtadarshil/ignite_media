part of 'show_password_cubit.dart';

@immutable
abstract class ShowPasswordState {}

class ShowPasswordInitial extends ShowPasswordState {
  final bool hidePassword;

  ShowPasswordInitial({this.hidePassword = false});
}

class ShowPassword extends ShowPasswordState {
  final bool showPassword;

  ShowPassword(this.showPassword);
}
