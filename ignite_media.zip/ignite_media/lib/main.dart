import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_notifications_handler/firebase_notifications_handler.dart';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:ignite_media/blocs/loading_indi_bloc.dart';
import 'package:ignite_media/pages/dashboard/dashboardscreen.dart';
import 'package:ignite_media/pages/intro/intro_screen.dart';
import 'package:ignite_media/utils/appcolors.dart';
import 'package:ignite_media/utils/strings.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await GetStorage.init();
  runApp(const MyApp());
}

final LoadingBloc loadingBloc = LoadingBloc();

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final FirebaseAuth auth = FirebaseAuth.instance;

  @override
  Widget build(BuildContext context) {
    return FirebaseNotificationsHandler(
      groupKey: Strings.loginTitle,
      onFCMTokenInitialize: (context, token) {
        if (auth.currentUser != null) {
          FirebaseFirestore.instance
              .collection('users')
              .doc(auth.currentUser!.uid)
              .update({'token': token});
        }
      },
      onTap: (navigatorKey, appState, payload) {},
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        builder: (context, child) {
          return StreamBuilder<bool>(
            initialData: false,
            stream: loadingBloc.loadingStream,
            builder: (context, snapshot) {
              return Stack(
                children: [
                  IgnorePointer(ignoring: snapshot.data!, child: child!),
                  snapshot.data!
                      ? Center(
                          child: LoadingAnimationWidget.twistingDots(
                          leftDotColor: AppColors.blackColor,
                          rightDotColor: AppColors.pinkColor,
                          size: 100,
                        ))
                      : const Offstage(),
                ],
              );
            },
          );
        },
        home: auth.currentUser == null
            ? const IntroScreen()
            : const DashboardScreen(),
      ),
    );
  }
}
