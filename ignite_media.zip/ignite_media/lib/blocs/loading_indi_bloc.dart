import 'dart:async';

class LoadingBloc {
  StreamController<bool> loadingStreamController = StreamController<bool>();

  Stream<bool> get loadingStream => loadingStreamController.stream;

  void startLoading() {
    loadingStreamController.sink.add(true);
  }

  void stopLoading() {
    loadingStreamController.sink.add(false);
  }

  void dispose() {
    loadingStreamController.close();
  }
}
