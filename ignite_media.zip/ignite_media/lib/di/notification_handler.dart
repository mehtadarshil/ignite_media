import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_notifications_handler/firebase_notifications_handler.dart';

class NotificationHandler {
  static Future sendNotification(
      {required String title,
      required String body,
      required String token}) async {
    var data = await FirebaseFirestore.instance
        .collection('users')
        .doc(FirebaseAuth.instance.currentUser!.uid)
        .get();
    FirebaseNotificationsHandler.sendNotification(
        cloudMessagingServerKey:
            'AAAAlnDqcEI:APA91bG_8vJFTiTZHIbnIUHB1sti5nKMRwMo7DJbTrwLNpInevImwfAoOm2yhv6ZjQFb6wQA4bNjeZV1gE39szsF3KBYQ-d9Ix799Qo62snJbMrPGKrk2mOYhWSyCoj2KR3-q3I6Gyd6',
        title: title,
        body: body,
        fcmTokens: [token]);
  }
}
