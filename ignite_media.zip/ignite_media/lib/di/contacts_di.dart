// ignore_for_file: avoid_function_literals_in_foreach_calls

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:contacts_service/contacts_service.dart';
import 'package:get_storage/get_storage.dart';
import 'package:ignite_media/utils/db_keys.dart';
import 'package:ignite_media/utils/models/user_model.dart';
import 'package:permission_handler/permission_handler.dart';

class ContactsDi {
  static Future<List<UserModel>> getContactsUser() async {
    final FirebaseFirestore firestore = FirebaseFirestore.instance;
    var data = await firestore.collection('users').get();
    List<UserModel> userList = [];
    if (await Permission.contacts.request().isGranted) {
      var contacts = await ContactsService.getContacts();

      contacts.forEach((element) {
        List<Item>? itemlist = element.phones;
        if (itemlist!.isNotEmpty) {
          String? number = element.phones!.first.value;
          final str = number?.replaceAll(" ", "");
          final str1 = str?.replaceAll("-", "");
          final numberFinal = str1?.replaceAll("+91", "");
          for (var user in data.docs) {
            if (user.get('number') == numberFinal &&
                numberFinal != GetStorage().read(DBkeys.currentNumber)) {
              userList.add(UserModel(
                  name: element.givenName!,
                  number: user.get('number'),
                  profile: user.get('profile'),
                  status: user.get('status'),
                  token: user.get('token')));
            }
          }
        }
      });
    }
    return userList;
  }

  static Future saveContacts() async {
    GetStorage().write(DBkeys.contactsList, await ContactsDi.getContactsUser());
    GetStorage().write(DBkeys.initial, true);
  }

  static Future<List<UserModel>> readContacts() async {
    List<UserModel> userList = [];
    if (GetStorage().read(DBkeys.contactsList) != null) {
      List data = GetStorage().read(DBkeys.contactsList);
      for (var element in data) {
        if (element is UserModel) {
          userList.add(element);
        } else {
          userList.add(UserModel.fromJson(element));
        }
      }
    }
    return userList;
  }
}
