class DBkeys {
  static const initial = 'init';
  static const contactsList = 'Contacts';
  static const currentNumber = 'current number';
}
