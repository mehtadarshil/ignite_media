import 'package:cloud_firestore/cloud_firestore.dart';

enum MessageType { text, reply, audio, video, photo }

class MessageData {
  final String messageId;
  final String sender;
  final bool isme;
  final String text;
  final Timestamp timestamp;
  final MessageType messageType;
  final String? reply;

  MessageData(
      {required this.messageId,
      required this.sender,
      required this.isme,
      required this.text,
      required this.timestamp,
      required this.messageType,
      this.reply = ''});
}
