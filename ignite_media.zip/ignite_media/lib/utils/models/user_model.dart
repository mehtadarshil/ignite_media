// To parse this JSON data, do
//
//     final userModel = userModelFromJson(jsonString);

import 'dart:convert';

UserModel userModelFromJson(String str) => UserModel.fromJson(json.decode(str));

String userModelToJson(UserModel data) => json.encode(data.toJson());

class UserModel {
  UserModel(
      {required this.name,
      required this.number,
      required this.profile,
      required this.status,
      required this.token});

  final String name;
  final String number;
  final String profile;
  final String status;
  final String token;

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
      name: json["name"],
      number: json["number"],
      profile: json["profile"],
      status: json["status"],
      token: json["token"]);

  Map<String, dynamic> toJson() => {
        "name": name,
        "number": number,
        "profile": profile,
        "status": status,
        "token": token
      };
}
