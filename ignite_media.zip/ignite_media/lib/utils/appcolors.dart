import 'package:flutter/material.dart';

class AppColors {
  static const primaryColor = Color(0xffD6E2EA);
  static const secondaryColor = Color.fromARGB(255, 50, 52, 59);
  static const whiteColor = Colors.white;
  static const blueColor = Colors.blue;
  static const unFocusedColor = Color.fromARGB(68, 101, 145, 181);
  static const focusedColor = Color.fromARGB(127, 63, 117, 161);
  static const blackColor = Color(0xFF1A1A3F);
  static const pinkColor = Color(0xFFEA3799);
}
