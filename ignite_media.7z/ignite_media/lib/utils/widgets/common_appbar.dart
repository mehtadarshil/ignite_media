import 'package:flutter/material.dart';
import 'package:ignite_media/utils/textstyle_extenstion.dart';

class CommonAppbar extends StatelessWidget {
  const CommonAppbar({
    Key? key,
    required this.onBack,
    required this.onExit,
    required this.title,
  }) : super(key: key);

  final VoidCallback onBack;
  final VoidCallback onExit;
  final String title;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        IconButton(
          onPressed: onBack,
          icon: const Icon(Icons.arrow_back_ios_new),
        ),
        Text(
          title,
          style: const TextStyle().bold,
        ),
        IconButton(onPressed: onExit, icon: const Icon(Icons.exit_to_app))
      ],
    );
  }
}
