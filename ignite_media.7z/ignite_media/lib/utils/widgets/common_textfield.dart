import 'package:flutter/material.dart';

class CommonTextField extends StatelessWidget {
  const CommonTextField(
      {Key? key,
      required this.controller,
      required this.hintText,
      required this.focusNode,
      required this.onChanged,
      required this.isPassword,
      required this.onTap,
      this.showPassword = false,
      required this.keyboardType})
      : super(key: key);

  final TextEditingController controller;
  final String hintText;
  final FocusNode focusNode;
  final Function(String) onChanged;
  final bool isPassword;
  final VoidCallback onTap;
  final bool showPassword;
  final TextInputType keyboardType;

  @override
  Widget build(BuildContext context) {
    return TextField(
      obscureText: !showPassword,
      keyboardType: keyboardType,
      focusNode: focusNode,
      controller: controller,
      onChanged: onChanged,
      decoration: InputDecoration(
          suffixIcon: isPassword
              ? GestureDetector(
                  onTap: onTap,
                  child: Icon(
                    Icons.remove_red_eye,
                    size: 20,
                    color: showPassword ? Colors.blue : Colors.grey,
                  ),
                )
              : const SizedBox.shrink(),
          hintText: hintText,
          focusedBorder:
              OutlineInputBorder(borderRadius: BorderRadius.circular(25)),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(25))),
    );
  }
}
