import 'package:flutter/material.dart';
import 'package:ignite_media/utils/appcolors.dart';
import 'package:ignite_media/utils/textstyle_extenstion.dart';

class LoginButton extends StatelessWidget {
  const LoginButton({
    Key? key,
    required this.text,
    required this.onPressed,
  }) : super(key: key);
  final String text;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 45,
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
          color: AppColors.secondaryColor,
          borderRadius: BorderRadius.circular(25)),
      child: MaterialButton(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
        onPressed: onPressed,
        child: Text(
          text,
          style: const TextStyle().buttonText,
        ),
      ),
    );
  }
}
