import 'package:flutter/material.dart';
import 'package:ignite_media/utils/appcolors.dart';

extension TextStyleHelper on TextStyle {
  TextStyle get bold => copyWith(fontSize: 20, fontFamily: 'poppins');
  TextStyle get buttonText => copyWith(
      fontSize: 21, fontWeight: FontWeight.bold, color: AppColors.whiteColor);
  TextStyle get clickableText =>
      copyWith(fontSize: 15, color: AppColors.blueColor);
}
