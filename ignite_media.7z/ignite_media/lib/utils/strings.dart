class Strings {
  //intro page strings
  static const introTitle = "Let's Talk";
  static const introDiscription =
      "Empowering communication, one message at a time";
  static const introSubDiscription =
      "Welcome to our chat app, where connecting with others has never been easier. Our app provides a simple and intuitive platform for you to communicate with friends, family, and colleagues in real-time, using text, voice, or video messages. With features such as push notifications, group chats, and file sharing, you can stay connected with the people that matter most, no matter where you are. Whether you're looking to catch up with friends, collaborate with coworkers, or simply chat with new people, our chat app has you covered. So why wait?";
  static const termAndCondition =
      '* By logining you are accepting our Term & Condition, and we respect privacy so dont worry about it.';

  //login page strings
  static const loginTitle = "Login";
  static const emailHintText = 'Enter Your Email or Username';
  static const passwordHintText = 'Enter Your Password';
  static const machineName = 'Login Machine';
  static const dontHaveAcc = 'Don\'t have Account, ';
  static const clickHere = 'Click Here';
  static const userNotExist = 'User does not Exist';

  //register page strings
  static const registerTitle = 'Register';
  static const onlyemailHintText = 'Enter Your Email';
  static const usernameHintText = 'Enter Your Username';
  static const numberHintText = 'Enter Your Number';
  static const alreadyHaveAcc = 'You already have Account, ';
  static const properInput = 'Enter Proper Inputs';
  static const alreadyTaken = 'Username or Email is already Taken';

  //otp Enter screen strings
  static const strVerifiaction = 'Verification';
  static const strSendTo = 'Enter the code send to number';

  //dashboard page strings
  static const contactTitle = 'Contacts';

  //assets path
  static const pandaRivePath = 'assets/2244-7248-animated-login-character.riv';
  static const registerAniPath = 'assets/72874-user-profile-v2.json';
  static const shapesRivePath = 'assets/shapes.riv';
  static const buttonRivePath = 'assets/button.riv';
}
