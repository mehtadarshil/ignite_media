import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:ignite_media/pages/loginscreen/loginscreen.dart';
import 'package:ignite_media/utils/appcolors.dart';
import 'package:ignite_media/utils/strings.dart';
import 'package:rive/rive.dart';
import 'package:ignite_media/utils/textstyle_extenstion.dart';

class IntroScreen extends StatefulWidget {
  const IntroScreen({super.key});

  @override
  State<IntroScreen> createState() => _IntroScreenState();
}

class _IntroScreenState extends State<IntroScreen> {
  late RiveAnimationController _btnController;
  @override
  void initState() {
    _btnController = OneShotAnimation('active', autoplay: false);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: Container(
              color: AppColors.primaryColor,
            ),
          ),
          const RiveAnimation.asset(Strings.shapesRivePath),
          Positioned.fill(
              child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: const SizedBox(),
          )),
          Padding(
            padding: const EdgeInsets.only(top: 30),
            child: SafeArea(
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 40),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      Strings.introTitle,
                      style: const TextStyle().bold.copyWith(fontSize: 60),
                    ),
                    const Text(
                      Strings.introSubDiscription,
                      style:
                          TextStyle(fontFamily: 'interSemiBold', fontSize: 19),
                    ),
                    const Spacer(),
                    GestureDetector(
                      onTap: () {
                        _btnController.isActive = true;
                        Future.delayed(const Duration(seconds: 1), () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const LoginScreen(),
                              ));
                        });
                      },
                      child: SizedBox(
                        height: 64,
                        width: 260,
                        child: Stack(
                          children: [
                            RiveAnimation.asset(
                              Strings.buttonRivePath,
                              controllers: [_btnController],
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: Center(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      Strings.loginTitle,
                                      style: const TextStyle().bold,
                                    ),
                                    const Icon(
                                      Icons.arrow_forward_ios_rounded,
                                      color: AppColors.blackColor,
                                    )
                                  ],
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    const Padding(
                      padding: EdgeInsets.only(left: 10),
                      child: Text(
                        Strings.termAndCondition,
                        style: TextStyle(fontFamily: 'inter', fontSize: 14),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
