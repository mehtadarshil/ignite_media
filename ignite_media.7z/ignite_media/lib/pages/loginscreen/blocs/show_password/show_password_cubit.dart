// ignore_for_file: depend_on_referenced_packages

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'show_password_state.dart';

class ShowPasswordCubit extends Cubit<ShowPassword> {
  ShowPasswordCubit() : super(ShowPassword(false));

  void showPassword() => emit(ShowPassword(true));
  void hidePassword() => emit(ShowPassword(false));
}
