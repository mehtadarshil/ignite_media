import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:ignite_media/di/register_di.dart';
import 'package:quickalert/quickalert.dart';

part 'register_event.dart';
part 'register_state.dart';

class RegisterBloc extends Bloc<RegisterEvent, RegisterState> {
  RegisterBloc() : super(RegisterInitial()) {
    on<RegisterUser>((event, emit) async {
      QuickAlert.show(
        barrierDismissible: false,
        context: event.context,
        type: QuickAlertType.loading,
        title: 'Loading',
        text: 'Making Your Account',
      );
      await RegisterDi.registerUser(event.password, event.email, event.number,
              event.username, event.context)
          .then((value) {
        Navigator.pop(event.context);
      });
    });
  }
}
