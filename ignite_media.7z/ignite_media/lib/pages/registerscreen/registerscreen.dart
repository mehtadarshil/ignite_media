import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ignite_media/di/register_di.dart';
import 'package:ignite_media/pages/loginscreen/blocs/show_password/show_password_cubit.dart';
import 'package:ignite_media/pages/registerscreen/blocs/register_bloc/register_bloc.dart';
import 'package:ignite_media/pages/registerscreen/widgets/alreadyhaveacc.dart';
import 'package:ignite_media/utils/appcolors.dart';
import 'package:ignite_media/utils/strings.dart';
import 'package:ignite_media/utils/widgets/common_appbar.dart';
import 'package:ignite_media/utils/widgets/common_textfield.dart';
import 'package:ignite_media/utils/widgets/loginbutton.dart';
import 'package:lottie/lottie.dart';
import 'package:quickalert/quickalert.dart';

class RegisterScreen extends StatelessWidget {
  RegisterScreen({super.key});

  final TextEditingController emailController = TextEditingController();
  final FocusNode emailfocusNode = FocusNode();
  final TextEditingController usernameController = TextEditingController();
  final FocusNode usernamefocusNode = FocusNode();
  final TextEditingController passwordController = TextEditingController();
  final FocusNode passwordfocusNode = FocusNode();
  final TextEditingController numberController = TextEditingController();
  final FocusNode numberfocusNode = FocusNode();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primaryColor,
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: BlocProvider(
          create: (context) => RegisterBloc(),
          child: BlocBuilder<RegisterBloc, RegisterState>(
            builder: (context, state) {
              return Column(
                children: [
                  const SizedBox(
                    height: 35,
                  ),
                  CommonAppbar(
                      onBack: () {
                        Navigator.pop(context);
                      },
                      onExit: () {
                        exit(0);
                      },
                      title: Strings.registerTitle),
                  Lottie.asset(Strings.registerAniPath, height: 300),
                  Container(
                    padding: const EdgeInsets.all(10),
                    margin: const EdgeInsets.symmetric(horizontal: 20),
                    decoration: BoxDecoration(
                        color: AppColors.whiteColor,
                        borderRadius: BorderRadius.circular(25)),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CommonTextField(
                          controller: emailController,
                          hintText: Strings.onlyemailHintText,
                          focusNode: emailfocusNode,
                          onChanged: (value) {},
                          isPassword: false,
                          showPassword: true,
                          onTap: () {},
                          keyboardType: TextInputType.emailAddress,
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        CommonTextField(
                          controller: usernameController,
                          hintText: Strings.usernameHintText,
                          focusNode: usernamefocusNode,
                          onChanged: (value) {},
                          isPassword: false,
                          showPassword: true,
                          onTap: () {},
                          keyboardType: TextInputType.text,
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        CommonTextField(
                          controller: numberController,
                          hintText: Strings.numberHintText,
                          focusNode: numberfocusNode,
                          onChanged: (value) {},
                          isPassword: false,
                          showPassword: true,
                          onTap: () {},
                          keyboardType: TextInputType.number,
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        BlocProvider(
                          create: (context2) => ShowPasswordCubit(),
                          child: BlocBuilder<ShowPasswordCubit, ShowPassword>(
                            builder: (context2, state) {
                              return CommonTextField(
                                controller: passwordController,
                                hintText: Strings.passwordHintText,
                                focusNode: passwordfocusNode,
                                onChanged: (value) {},
                                isPassword: true,
                                keyboardType: TextInputType.visiblePassword,
                                showPassword: state.showPassword,
                                onTap: () {
                                  if (state.showPassword) {
                                    BlocProvider.of<ShowPasswordCubit>(context2)
                                        .hidePassword();
                                  } else {
                                    BlocProvider.of<ShowPasswordCubit>(context2)
                                        .showPassword();
                                  }
                                },
                              );
                            },
                          ),
                        ),
                        const SizedBox(
                          height: 25,
                        ),
                        LoginButton(
                          text: Strings.registerTitle,
                          onPressed: () async {
                            if (emailController.text.isNotEmpty &&
                                usernameController.text.isNotEmpty &&
                                numberController.text.length == 10 &&
                                passwordController.text.isNotEmpty) {
                              if (await RegisterDi.checkUsernameAvailable(
                                  usernameController.text,
                                  emailController.text)) {
                                QuickAlert.show(
                                    context: context,
                                    type: QuickAlertType.error,
                                    title: Strings.alreadyTaken);
                              } else {
                                QuickAlert.show(
                                    context: context,
                                    type: QuickAlertType.loading);
                                BlocProvider.of<RegisterBloc>(context).add(
                                    RegisterUser(
                                        email: emailController.text,
                                        username: usernameController.text,
                                        number: numberController.text,
                                        password: passwordController.text,
                                        context: context));
                              }
                            } else {
                              QuickAlert.show(
                                  context: context,
                                  type: QuickAlertType.error,
                                  title: Strings.properInput);
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 25,
                  ),
                  AlreadyHaveAcc(
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),
                  const SizedBox(
                    height: 50,
                  )
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}
