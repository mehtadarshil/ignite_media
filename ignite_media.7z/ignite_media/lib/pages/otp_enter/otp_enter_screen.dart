import 'package:flutter/material.dart';
import 'package:ignite_media/utils/appcolors.dart';
import 'package:ignite_media/utils/strings.dart';
import 'package:pinput/pinput.dart';
import 'package:ignite_media/utils/textstyle_extenstion.dart';

class OptEnterScreen extends StatelessWidget {
  const OptEnterScreen({
    super.key,
    required this.number,
  });

  final String number;

  @override
  Widget build(BuildContext context) {
    final defaultPinTheme = PinTheme(
      width: 56,
      height: 56,
      textStyle: const TextStyle(
        fontSize: 22,
        color: Color.fromRGBO(30, 60, 87, 1),
      ),
      decoration: BoxDecoration(
        color: AppColors.focusedColor,
        borderRadius: BorderRadius.circular(19),
      ),
    );

    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              Strings.strVerifiaction,
              style: const TextStyle().bold,
            ),
            const SizedBox(
              height: 20,
            ),
            const Text(Strings.strSendTo),
            Pinput(
              defaultPinTheme: defaultPinTheme,
              senderPhoneNumber: number,
              androidSmsAutofillMethod:
                  AndroidSmsAutofillMethod.smsUserConsentApi,
              focusedPinTheme: defaultPinTheme.copyWith(
                decoration: defaultPinTheme.decoration!.copyWith(
                    borderRadius: BorderRadius.circular(8),
                    color: AppColors.focusedColor),
              ),
              submittedPinTheme: defaultPinTheme.copyWith(
                decoration: defaultPinTheme.decoration!.copyWith(
                  color: AppColors.unFocusedColor,
                  borderRadius: BorderRadius.circular(19),
                ),
              ),
              length: 6,
              autofocus: true,
              onCompleted: (value) {
                Navigator.pop(context, value);
              },
            ),
          ],
        ),
      ),
    );
  }
}
