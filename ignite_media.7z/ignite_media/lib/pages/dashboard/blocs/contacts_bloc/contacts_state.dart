part of 'contacts_bloc.dart';

@immutable
abstract class ContactsState {}

class ContactsInitial extends ContactsState {}

class ContactsList extends ContactsState {
  final List<UserModel> contacts;

  ContactsList(this.contacts);
}

class ContactLoading extends ContactsState {}
