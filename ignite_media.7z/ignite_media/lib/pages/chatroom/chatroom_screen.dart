import 'package:chat_bubbles/chat_bubbles.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_storage/get_storage.dart';
import 'package:ignite_media/di/chat_handler_di.dart';
import 'package:ignite_media/pages/chatroom/blocs/reply_controller/reply_controller_bloc.dart';
import 'package:ignite_media/utils/appcolors.dart';
import 'package:ignite_media/utils/db_keys.dart';
import 'package:ignite_media/utils/models/message_data_model.dart';
import 'package:ignite_media/utils/models/user_model.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';

class ChatRoomScreen extends StatelessWidget {
  ChatRoomScreen({super.key, required this.chatroom, required this.userModel});
  final String chatroom;
  final UserModel userModel;

  final ReplyControllerBloc replyControllerBloc = ReplyControllerBloc();

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => replyControllerBloc,
      child: Scaffold(
        backgroundColor: AppColors.primaryColor,
        appBar: AppBar(
          leading: IconButton(
              iconSize: 20,
              onPressed: () {
                Navigator.pop(context);
              },
              icon: const Icon(Icons.arrow_back_ios)),
          backgroundColor: AppColors.focusedColor,
          title: Text(userModel.name),
        ),
        body: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance
              .collection('chatroom')
              .doc(chatroom)
              .collection('chats')
              .orderBy('time', descending: false)
              .snapshots(),
          builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (snapshot.hasData) {
              final messagesList = snapshot.data!.docs.reversed;
              List<GestureDetector> messagebubbles = [];
              for (var message in messagesList) {
                final messagedata = MessageData(
                    messageId: message.id,
                    sender: message.get('sender'),
                    isme: message.get('sender') ==
                        GetStorage().read(DBkeys.currentNumber),
                    text: message.get('text'),
                    timestamp: message.get('time'),
                    messageType: message.get('type') == 0
                        ? MessageType.text
                        : MessageType.reply,
                    reply: message.get('reply'));
                final messagebubble = GestureDetector(
                  onHorizontalDragEnd: (details) {
                    replyControllerBloc.add(OnReplyAdd(messagedata.text));
                  },
                  child: BubbleSpecialThree(
                    text: messagedata.text,
                    color: messagedata.isme
                        ? AppColors.focusedColor
                        : AppColors.whiteColor,
                    isSender: messagedata.isme,
                    tail: true,
                  ),
                );
                messagebubbles.add(messagebubble);
              }
              return Column(
                children: [
                  Expanded(
                    child: SizedBox(
                      child: ListView(
                        reverse: true,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 20),
                        children: messagebubbles,
                      ),
                    ),
                  ),
                  BlocBuilder<ReplyControllerBloc, ReplyControllerState>(
                    builder: (context, state) {
                      if (state is ReplyedTextState) {
                        return MessageBar(
                          replying: true,
                          onTapCloseReply: () {
                            replyControllerBloc.add(OnReplyRemove());
                          },
                          replyingTo: state.replyText,
                          onSend: (message) {
                            ChatHandler.sendMessage(
                                chatroomID: chatroom,
                                text: message,
                                name: userModel.name,
                                token: userModel.token,
                                reply: state.replyText);
                            replyControllerBloc.add(OnReplyRemove());
                          },
                        );
                      } else {
                        return MessageBar(
                          onSend: (message) {
                            ChatHandler.sendMessage(
                                chatroomID: chatroom,
                                text: message,
                                name: userModel.name,
                                token: userModel.token);
                          },
                        );
                      }
                    },
                  )
                ],
              );
            } else {
              return Center(
                child: LoadingAnimationWidget.hexagonDots(
                    color: AppColors.focusedColor, size: 60),
              );
            }
          },
        ),
      ),
    );
  }
}
