import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'reply_controller_event.dart';
part 'reply_controller_state.dart';

class ReplyControllerBloc
    extends Bloc<ReplyControllerEvent, ReplyControllerState> {
  ReplyControllerBloc() : super(ReplyControllerInitial()) {
    on<OnReplyAdd>((event, emit) {
      emit(ReplyedTextState(event.replyText));
    });

    on<OnReplyRemove>((event, emit) {
      emit(ReplyControllerInitial());
    });
  }
}
