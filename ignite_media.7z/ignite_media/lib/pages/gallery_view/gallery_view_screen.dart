// import 'dart:io';

// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:custom_gallery_display/custom_gallery_display.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:firebase_storage/firebase_storage.dart';
// import 'package:flutter/material.dart';
// import 'package:ignite_media/utils/models/user_model.dart';
// import 'package:uuid/uuid.dart';

// class Galleryaccess extends StatelessWidget {
//   Galleryaccess(this.chatroomID, this.user, {super.key});
//   final String chatroomID;
//   final UserModel user;

//   File? imagefile;
//   final FirebaseAuth _auth = FirebaseAuth.instance;
//   final FirebaseFirestore _firestore = FirebaseFirestore.instance;

//   Future uploadimage() async {
//     try {
//       await CustomGalleryPermissions.requestPermissionExtend();
//     } catch (e) {
//       print(e.toString());
//     }

//     String filename = const Uuid().v1();
//     int status = 1;

//     await _firestore
//         .collection('chatroom')
//         .doc(chatroomID)
//         .collection('chats')
//         .doc(filename)
//         .set({
//       'sendby': _auth.currentUser!.phoneNumber,
//       'type': 'img',
//       'message': '',
//       'time': DateTime.now(),
//       'reply': ''
//     });
//     var ref =
//         FirebaseStorage.instance.ref().child('images').child('$filename.jpg');

//     var uploadtask = await ref.putFile(imagefile!).catchError((e) async {
//       await _firestore
//           .collection('chatroom')
//           .doc(chatroomID)
//           .collection('chats')
//           .doc(filename)
//           .delete();
//       status = 0;
//     });
//     if (status == 1) {
//       String imageurl = await uploadtask.ref.getDownloadURL();
//       await _firestore
//           .collection('chatroom')
//           .doc(chatroomID)
//           .collection('chats')
//           .doc(filename)
//           .update({'message': imageurl});
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: CustomGallery.normalDisplay(
//         enableCamera: false,
//         enableVideo: false,
//         gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//           crossAxisCount: 4,
//           crossAxisSpacing: 1.7,
//           mainAxisSpacing: 1.5,
//         ),
//         sendRequestFunction: (SelectedImagesDetails details) async {
//           File selectedFile = details.selectedFile;
//           imagefile = selectedFile;
//           Navigator.pop(context);
//           await uploadimage();
//         },
//       ),
//     );
//   }
// }
