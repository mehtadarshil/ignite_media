import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get_storage/get_storage.dart';
import 'package:ignite_media/di/notification_handler.dart';
import 'package:ignite_media/utils/db_keys.dart';

class ChatHandler {
  static void sendMessage(
      {required String chatroomID,
      required String text,
      required String name,
      required String token,
      String? reply}) {
    if (text.isNotEmpty) {
      NotificationHandler.sendNotification(
          body: text, title: name, token: token);
      final FirebaseFirestore firestore = FirebaseFirestore.instance;
      firestore.collection('chatroom').doc(chatroomID).collection('chats').add({
        'text': text,
        'sender': GetStorage().read(DBkeys.currentNumber),
        'time': DateTime.now(),
        'type': reply != null ? 1 : 0,
        'reply': reply ?? ''
      });
    }
  }

  static String chatroomidMaker(String user1, String user2) {
    if (user1.hashCode > user2.hashCode) {
      return (user1.hashCode - user2.hashCode).toString();
    } else {
      return (user2.hashCode - user1.hashCode).toString();
    }
  }
}
