import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:ignite_media/pages/dashboard/dashboardscreen.dart';
import 'package:ignite_media/pages/otp_enter/otp_enter_screen.dart';
import 'package:ignite_media/utils/db_keys.dart';
import 'package:quickalert/quickalert.dart';

class RegisterDi {
  static Future<bool> checkUsernameAvailable(
      String username, String email) async {
    final FirebaseFirestore cloudFirestore = FirebaseFirestore.instance;
    var data = await cloudFirestore.collection('users').get();

    return data.docs.any((element) =>
        element.get('username') == username || element.get('email') == email);
  }

  static Future registerUser(String password, String email, String number,
      String username, BuildContext context) async {
    QuickAlert.show(
        context: context,
        type: QuickAlertType.loading,
        barrierDismissible: false);
    final FirebaseFirestore cloudFirestore = FirebaseFirestore.instance;
    final FirebaseAuth firebaseAuth = FirebaseAuth.instance;
    await firebaseAuth
        .verifyPhoneNumber(
      phoneNumber: '+91$number',
      verificationCompleted: (phoneAuthCredential) {},
      verificationFailed: (error) {
        QuickAlert.show(
            context: context, type: QuickAlertType.error, title: error.message);
      },
      codeSent: (verificationId, forceResendingToken) async {
        String otp = await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => OptEnterScreen(
                number: number,
              ),
            ));
        try {
          firebaseAuth
              .signInWithCredential(PhoneAuthProvider.credential(
                  verificationId: verificationId, smsCode: otp))
              .then((value) async {
            var token = await FirebaseMessaging.instance.getToken();
            firebaseAuth.signOut();
            await firebaseAuth.createUserWithEmailAndPassword(
                email: email, password: password);
            GetStorage().write(DBkeys.currentNumber, number);
            await cloudFirestore
                .collection('users')
                .doc(firebaseAuth.currentUser?.uid)
                .set({
              'profile': '',
              'email': email,
              'username': username,
              'number': number,
              'status': 'Hey! , i am using INGITE MEDIA',
              'token': token
            }).then((value) {
              Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const DashboardScreen(),
                  ),
                  (route) => false);
            });
          });
        } catch (e) {
          QuickAlert.show(
              context: context,
              type: QuickAlertType.error,
              title: e.toString());
        }
      },
      codeAutoRetrievalTimeout: (verificationId) {},
    )
        .then((value) {
      Navigator.pop(context);
    });
  }
}
