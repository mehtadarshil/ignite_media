// ignore_for_file: avoid_function_literals_in_foreach_calls

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:ignite_media/main.dart';
import 'package:ignite_media/pages/dashboard/dashboardscreen.dart';
import 'package:ignite_media/pages/loginscreen/loginscreen.dart';
import 'package:ignite_media/utils/db_keys.dart';
import 'package:quickalert/quickalert.dart';

class LoginDi {
  static Future loginUser(
      String query, String password, BuildContext context) async {
    final FirebaseFirestore firestore = FirebaseFirestore.instance;
    final FirebaseAuth firebaseAuth = FirebaseAuth.instance;

    loadingBloc.startLoading();
    var data = await firestore.collection('users').get();
    data.docs.forEach((element) {
      if (element.get('username') == query ||
          element.get('number') == query ||
          element.get('email') == query) {
        try {
          firebaseAuth
              .signInWithEmailAndPassword(
                  email: element.get('email'), password: password)
              .then((value) async {
            firestore
                .collection('users')
                .doc(firebaseAuth.currentUser!.uid)
                .update({'token': FirebaseMessaging.instance.getToken()});
            await GetStorage()
                .write(DBkeys.currentNumber, element.get('number'))
                .then((value) => Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const DashboardScreen(),
                    ),
                    (route) => false));
          });
        } catch (e) {
          QuickAlert.show(
              context: context,
              type: QuickAlertType.error,
              title: e.toString());
        }
      } else {
        loadingBloc.stopLoading();
      }
    });
  }

  static void logoutUser(BuildContext context) {
    FirebaseAuth.instance.signOut();
    Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (context) => const LoginScreen(),
        ),
        (route) => false);
  }
}
