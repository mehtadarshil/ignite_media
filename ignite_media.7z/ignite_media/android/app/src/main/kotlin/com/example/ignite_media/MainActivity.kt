package com.example.ignite_media

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
